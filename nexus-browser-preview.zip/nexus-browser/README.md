# NEXUS Browser — Preview 0.1

NEXUS est un tableau de bord web personnel avec une interface de navigation intégrée, des raccourcis, des favoris, un historique local et deux mini-jeux.

## Important : limites de cette version

Cette version est une application web statique (HTML/CSS/JavaScript), pas un proxy réseau ni un navigateur Chromium distant.

- Les sites qui autorisent l'intégration peuvent s'afficher dans le cadre intégré.
- Certains sites bloquent les iframes avec leurs politiques de sécurité. Utilisez le bouton d'ouverture externe.
- Cette application ne contourne pas les restrictions d'un réseau, d'un établissement ou d'un service tiers.
- Les favoris et l'historique sont stockés localement dans le navigateur de l'appareil.
- Le moteur Chromium distant, les comptes et la synchronisation GitHub ne sont pas inclus dans cette première version.

## Lancer localement

Ouvrez `index.html` dans un navigateur. Pour tester le mode PWA/service worker, servez le dossier via un serveur HTTP local ou publiez-le sur un hébergement statique HTTPS.

## Déploiement gratuit

Vous pouvez importer ce dossier dans un dépôt GitHub, puis connecter le dépôt à Cloudflare Pages.

Paramètres Cloudflare Pages pour ce projet :
- Framework preset : None
- Build command : (laisser vide)
- Build output directory : `/` ou le dossier racine du projet

Vérifiez le chemin de publication proposé par l'interface Cloudflare avant de déployer.

## Fichiers

- `index.html` : structure des pages
- `styles.css` : thème responsive
- `app.js` : navigation de l'interface, favoris, historique et mini-jeux
- `manifest.webmanifest` : configuration PWA
- `sw.js` : cache des fichiers statiques
- `assets/icon.svg` : icône NEXUS

## Sécurité

Ne saisissez pas de mots de passe sensibles dans une page intégrée non vérifiée. N'ajoutez pas de proxy ouvert. Toute future fonctionnalité de navigation distante devra être isolée, authentifiée, limitée en ressources et protégée contre les accès réseau non autorisés.
